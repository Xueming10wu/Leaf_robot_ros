#ifndef LEAFROBOT_H
#define LEAFROBOT_H

#include "leaf_driver/common.h"
#include "leaf_driver/ManipulatorProtocol.h"


//相当于MyRbot
class LeafRobot : public hardware_interface::RobotHW
{
public:
    LeafRobot();
    virtual ~LeafRobot();
    void home();        //收起来
    void zero();        //直立起来
    void read();
    void write();
    

private:
    hardware_interface::JointStateInterface jnt_state_interface;
    hardware_interface::PositionJointInterface jnt_pos_interface;

    //串口
    string serialport_name;
    int baudrate;

    //通讯协议对象
    ManipulatorProtocol * manipulatorProtocolPtr;

    //通讯质量
    int errortimes;
    long reads;
    long writes;

    //自由度
    const int joint_count;
    string * joint_name;
    double * cmd; 
    double * pos;
    double * vel;
    double * eff;

    //各个关节转PI/2需要的节拍
    int * plu2angel;
    int * zeroPlu;
};

#endif //LEAFROBOT
