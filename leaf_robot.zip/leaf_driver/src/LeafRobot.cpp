#include "leaf_driver/LeafRobot.h"


LeafRobot::LeafRobot() : joint_count(6)
{   
    //私有参数 获取
    ros::NodeHandle nh_private("~");
    nh_private.param<string>("serialport_name", serialport_name, "/dev/ttyACM0");
    nh_private.param<int>("baudrate", baudrate, 38400);

    //初始化一些变量
    joint_name = new string[joint_count];
    cmd = new double[joint_count];
    pos = new double[joint_count];
    vel = new double[joint_count];
    eff = new double[joint_count];
    plu2angel = new int[joint_count];
    zeroPlu = new int[joint_count];

    //重要参数
    //旋转+90°(+1.5707963)，需要的节拍
    plu2angel[0] = -7800;
    plu2angel[1] = -6350;
    plu2angel[2] = -8000;
    plu2angel[3] = -4550;
    plu2angel[4] = -3400;
    plu2angel[5] = -3200;

    //零点参数
    zeroPlu[0] = 0;
    zeroPlu[1] = -5600;
    zeroPlu[2] = 6600;
    zeroPlu[3] = 0;
    zeroPlu[4] = -3400;
    zeroPlu[5] = 0;

    for (size_t i = 0; i < joint_count; i++)
    {
        cmd[i] = 0;
        pos[i] = 0;
        vel[i] = 0;
        eff[i] = 0;
    }
    errortimes = 0;
    reads = 0;
    writes = 0;
    
    //关节命名
    stringstream ss;
    ss.clear();ss.str("");
    for (size_t i = 0; i < joint_count; i++)
    {
        ss << "joint" << i + 1;
        joint_name[i] = ss.str();
        ss.clear();ss.str("");
    }

    //初始化协议
    manipulatorProtocolPtr = new ManipulatorProtocol();
    manipulatorProtocolPtr->manipulatorInit(joint_count);
    manipulatorProtocolPtr->setSerialPort(serialport_name, baudrate);

    //状态发布控制器  用于反馈机械臂实时状态
    vector<hardware_interface::JointStateHandle> state_handle;//添加关节
    for (size_t i = 0; i < joint_count; i ++)
    {
        state_handle.push_back( hardware_interface::JointStateHandle(joint_name[i], &pos[i], &vel[i], &eff[i]) );
        jnt_state_interface.registerHandle(state_handle[i]);
    }
    //控制器注册
    registerInterface(&jnt_state_interface);


    //位置控制器 用于发布机械臂需要移动到的位置
    std::vector<hardware_interface::JointHandle> pos_handle;//添加关节
    for (size_t i = 0; i < joint_count; i++)
    {
        pos_handle.push_back(hardware_interface::JointHandle(jnt_state_interface.getHandle(joint_name[i]), &cmd[i]));
        jnt_pos_interface.registerHandle(pos_handle[i]);
    }
    //控制器注册
    registerInterface(&jnt_pos_interface);
    cout << "机械臂初始化中..." << endl;
    usleep(1000000);
    manipulatorProtocolPtr->udpHandle->serialPort->flush ();
    //到达0点
    zero();
    cout << "机械臂到达零点位置..." <<endl;
    usleep(4000000);
    cout << "机械臂到位置完毕" <<endl;
}

LeafRobot::~LeafRobot()
{   
    cout << "机械臂程序正在关闭..." << endl;
    home();
    usleep(2000000);//等待2s
    home();
    usleep(2000000);//等待2s
    home();
    usleep(2000000);//等待2s
    delete manipulatorProtocolPtr;
    delete []joint_name;
    delete []cmd;
    delete []pos;
    delete []vel;
    delete []eff;
    delete []plu2angel;
    
    manipulatorProtocolPtr = NULL;
    joint_name = NULL;
    cmd = NULL;
    pos = NULL;
    vel = NULL;
    eff = NULL;
    plu2angel = NULL;
    cout << "机械臂程序已退出，请关掉电源，以免电机过热。"<< endl;
}


void LeafRobot::home()
{
    writes++;
    manipulatorProtocolPtr->manipulator.stepMotorList[0].position = 0;
    manipulatorProtocolPtr->manipulator.stepMotorList[1].position = 0;
    manipulatorProtocolPtr->manipulator.stepMotorList[2].position = 0;
    manipulatorProtocolPtr->manipulator.stepMotorList[3].position = 0;
    manipulatorProtocolPtr->manipulator.stepMotorList[4].position = 0;
    manipulatorProtocolPtr->manipulator.stepMotorList[5].position = 0;
    manipulatorProtocolPtr->write();
    //cout << "home..." << endl << endl;
}

void LeafRobot::zero()
{
    writes++;
    for (size_t i = 0; i < joint_count; i ++)
    {
        manipulatorProtocolPtr->manipulator.stepMotorList[i].position = zeroPlu[i];
    }
    manipulatorProtocolPtr->write();
    cout << "zero..." << endl << endl;
}


void LeafRobot::read()
{   
    if (manipulatorProtocolPtr->udpHandle->serialPort->available()  >= 57)
    {
        if (manipulatorProtocolPtr->read() == -1)
        {
            errortimes++;
        }
        else
        {
            reads++;
            //执行动作
            for (size_t i = 0; i < manipulatorProtocolPtr->manipulator.degrees ; i ++)
            {//获取到数据 写入到pos中
                pos[i] =  (manipulatorProtocolPtr->manipulator.stepMotorList[i].position - zeroPlu[i]) * PI / (2 * plu2angel[i]);
                //cout << manipulatorProtocolPtr->manipulator.stepMotorList[i].position << " ";
                cout << pos[i] << " ";
            }
            cout << "  , error : " << errortimes
                    << "  , R : " << reads
                    << "  , W : " << writes 
                    << "  , Rate: " << (double)(reads-errortimes) * 100 / (double)reads 
                    <<"%"<< endl;
        }
    }
}

void LeafRobot::write()
{
    writes++;
    //从cmd中获取数据
     cout << "writing ";
    for (size_t i = 0; i < joint_count; i++)
    {
        manipulatorProtocolPtr->manipulator.stepMotorList[i].position = round(cmd[i] * 2 * plu2angel[i] / PI) + zeroPlu[i];
        cout << cmd[i] << " ";
    }
    manipulatorProtocolPtr->write();
    cout << endl ;
}
