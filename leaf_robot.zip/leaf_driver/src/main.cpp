#include "leaf_driver/LeafRobot.h"

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "leaf_node");
    LeafRobot robot;
    controller_manager::ControllerManager cm(&robot);
    ros::AsyncSpinner spinner(1);
    spinner.start();

    //Control loop
    ros::Time prev_time = ros::Time::now();
    //ros::Rate loop_rate(10);

    int loops = 0;

    while (ros::ok())
    {
        const ros::Time time = ros::Time::now();
        const ros::Duration period = time - prev_time;
        robot.read();
        loops ++;
        usleep(5000);
        if(loops >= 10)
        {
            loops = 0;
            robot.write();
        }
        cm.update(time, period);
        usleep(5000);
    }
    return 0;
}
